import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {

  
   }
   add(){  
    let row = document.createElement('div');   
      row.className = 'row'; 
      row.innerHTML = ` 
      <br> 
      <input type="text" style="width:auto;background-color:#F0FFF0;">`; 
      document.querySelector('.showInputField').appendChild(row); 
  }
  add2(){  
    let row = document.createElement('div');   
      row.className = 'row'; 
      row.innerHTML = ` 
      <br> 
      <input type="textarea" onkeypress="this.style.width = ((this.value.length + 1) * 8) + 'px';"style="width:auto;border:none;background-color:#F0FFF0;">`; 
      document.querySelector('.showInputField1').appendChild(row); 
  }
 add1(){ 
var c = <HTMLCanvasElement> document.getElementById("myCanvas");
var ctx = c.getContext("2d");
ctx.beginPath();
ctx.rect(190, 20, 300, 450);
ctx.stroke();
}

}
