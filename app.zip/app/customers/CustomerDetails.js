import React, {useEffect, useState} from "react";
import CompanyLogo from "../../assets/emersion.png";
import service from "../service/service.js";
import {Col, Container, Image, Row, Spinner} from "react-bootstrap";
import BulletList from "../../components/BulletList";
import BreadCrumb from "../../components/BreadCrumb";
import customers from "../../assets/customers.png";
import {ReactComponent as BreadcrumbArtwork} from "../../assets/customer-artwork.svg";
import {Link} from "react-router-dom";
import {ReactComponent as DoubleArrowRight} from "../../assets/double_arrow_right.svg";
import CustomerValues from "./CustomerValues";
import CustomerTeam from "./CustomerTeam";
import SamplePic from "../../assets/sample_image.png";
import CustomSpinner from "../../components/CustomSpinner";

export default function CustomerDetails({match: {params: {customer_slug}}}) {
  const [breadcrumb_data, setBreadcrumb] = useState([
    {
      'link': '/slk-hub/',
      'name': 'Home'
    },
    {
      'link': '/slk-hub/customerssss/',
      'name': 'Our Customers'
    }
  ])
  const [details, setData] = useState({})
  const [fetching, setFetching] = useState(true)
  const [tab_loading, setTabLoading] = useState(false)
  const [active_tab, setActiveTab] = useState('know')
  const [show_value_modal, setValueModal] = useState({})

  

  //const sample_detail_response ={"customer":"../../assets/emersion.png","solution":"Inflation Model","year":"2001","slk_champion":"Nagesh KP","slug":"emersion_1","title":"Emersion","timeline":["Customer since - 1998","Industry - Automation-Solutions","Projects 1 - Automation Engineering","Projects 2 Industrial Wireless Technology","Award - Operational Excellence"],"detail":{"title":"Case Study: Inflation Model","type":"Type: New Solution/Application Key Words:","summary":"","keywords":["Procurement","Forecast","Data Analysis","Reports","Under Estimation"]},"docs":[{"video":"video/video1.mp4","title":"Video 1","tag":"Test tags"},{"video":"video/video2.mp4","title":"Video 2","tag":"Test tags"}],"values":[{"year":"2000","value":"The Begining","about":"Description"},{"year":"2001","value":"Inflation Model","about":"Description"},{"year":"2003","value":"Symphony","about":"Description"},{"year":"2006","value":"Configurator","about":"Description"}],"external_links":[{"url":"www.financeemerson.com","text":"Financials"},{"url":"www.financeemerson.com","text":"Financials"},{"url":"www.financeemerson.com","text":"Financials"},{"url":"www.financeemerson.com","text":"Financials"}],"slk_team":[{"name":"Rajesh M","designation":"Project manager","email":"mag@slkgroup.com","contact":"222341111","avatar":""},{"name":"Ramesh","designation":"Architect","email":"ramesh@slkgroup.com","contact":"222341111","avatar":""}],"client_team":[{"name":"Rajesh M","designation":"Project manager","email":"mag@slkgroup.com","contact":"222341111","avatar":""},{"name":"Ramesh","designation":"Architect","email":"ramesh@slkgroup.com","contact":"222341111","avatar":""}]}
  // const sample_detail_response = {
  //   customer: CompanyLogo,
  //   solution: "Inflation Model",
  //   year: "2001",
  //   slk_champion: "Nagesh KP",
  //   slug: 'emersion_1',
  //   title: 'Emersion',
  //   detail: {
  //     title: "Case Study: Inflation Model",
  //     type: "Type: New Solution/Application Key Words:",
  //     summary: "",
  //     keywords: ["Procurement", "Forecast", "Data Analysis", "Reports", "Under Estimation"]
  //   },
  //   timeline: [
  //     "Customer since - 1998", "Industry - Automation-Solutionsrfghjknbvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv",
  //     "Projects 1 - Automation Engineering",
  //     "Projects 2 Industrial Wireless Technology",
  //     "Award - Operational Excellence"
  //   ],
  //   docs: [
  //     {
  //       'video': SampleVideo,
  //       'title': 'Evolving from Automation to Hyper Automation',
  //       'tag': 'Document'
  //     },
  //     {
  //       'video': SampleVideo,
  //       'title': 'The Future of Blockchain',
  //       'tag': ''
  //     },
  //     {
  //       'video': SampleVideo,
  //       'title': 'How to transition from Monolithic to Microservices?',
  //       'tag': 'Document'
  //     }
  //   ],
  //   external_links: [
  //     {
  //       url: '#',
  //       text: 'www.emerson.com'
  //     },
  //     {
  //       url: '#',
  //       text: 'Leadership Team'
  //     },
  //     {
  //       url: '#',
  //       text: 'Products & Services'
  //     },
  //     {
  //       url: '#',
  //       text: 'Financials'
  //     }
  //   ],
  //   values: [
  //     {
  //       year: '2000',
  //       value: 'The Beginning',
  //       about: 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text.'
  //     },
  //     {
  //       year: '2001',
  //       value: 'Inflation Model',
  //       about: 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text.'
  //     },
  //     {
  //       year: '2002',
  //       value: 'Symphony',
  //       about: 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text.'
  //     },
  //     {
  //       year: '2003',
  //       value: 'Configurator',
  //       about: 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text.'
  //     }
  //   ],
  //   slk_team: [
  //     {
  //       name: 'Rajesh M',
  //       designation: 'Designation',
  //       email: 'rajeshM@slk.com',
  //       contact: '+91 98804 55226',
  //       avatar: SamplePic,
  //     },
  //     {
  //       name: 'Rajesh M',
  //       designation: 'Designation',
  //       email: 'rajeshM@slk.com',
  //       contact: '+91 98804 55226',
  //       avatar: SamplePic,
  //     },
  //     {
  //       name: 'Rajesh M',
  //       designation: 'Designation',
  //       email: 'rajeshM@slk.com',
  //       contact: '+91 98804 55226',
  //       avatar: SamplePic,
  //     },
  //     {
  //       name: 'Rajesh M',
  //       designation: 'Designation',
  //       email: 'rajeshM@slk.com',
  //       contact: '+91 98804 55226',
  //       avatar: SamplePic,
  //     },
  //     {
  //       name: 'Rajesh M',
  //       designation: 'Designation',
  //       email: 'rajeshM@slk.com',
  //       contact: '+91 98804 55226',
  //       avatar: SamplePic,
  //     },
  //     {
  //       name: 'Rajesh M',
  //       designation: 'Designation',
  //       email: 'rajeshM@slk.com',
  //       contact: '+91 98804 55226',
  //       avatar: SamplePic,
  //     }
  //   ],
  //   client_team: [
  //     {
  //       name: 'Rajesh M',
  //       designation: 'Designation',
  //       email: 'rajeshM@slk.com',
  //       contact: '+91 98804 55226',
  //       avatar: SamplePic,
  //     },
  //     {
  //       name: 'Rajesh M',
  //       designation: 'Designation',
  //       email: 'rajeshM@slk.com',
  //       contact: '+91 98804 55226',
  //       avatar: SamplePic,
  //     },
  //     {
  //       name: 'Rajesh M',
  //       designation: 'Designation',
  //       email: 'rajeshM@slk.com',
  //       contact: '+91 98804 55226',
  //       avatar: SamplePic,
  //     },
  //     {
  //       name: 'Rajesh M',
  //       designation: 'Designation',
  //       email: 'rajeshM@slk.com',
  //       contact: '+91 98804 55226',
  //       avatar: SamplePic,
  //     },
  //     {
  //       name: 'Rajesh M',
  //       designation: 'Designation',
  //       email: 'rajeshM@slk.com',
  //       contact: '+91 98804 55226',
  //       avatar: SamplePic,
  //     },
  //     {
  //       name: 'Rajesh M',
  //       designation: 'Designation',
  //       email: 'rajeshM@slk.com',
  //       contact: '+91 98804 55226',
  //       avatar: SamplePic,
  //     }
  //   ]
  // }

  const toggle_tab = (tab) => {
    setTabLoading(true)
    setActiveTab(tab)
    setTimeout(() => {
      setTabLoading(false)
    }, 1000)
  }
  const fetch_detail_data = (impact_slug) => {
    var results;
    //alert(customer_slug)
    service.getcustdetailsbyid(customer_slug)
    .then(res => {
       results=res.data;
        console.log(results);    
   setFetching(true)
   setData(results)
   setBreadcrumb([
    {
      'link': '/',
      'name': 'Home'
    },
    {
      'link': 'slk-hub/customers/',
      'name': 'Our Customers'
    },
    {
      'link': `slk-hub/customers/${customer_slug}/`,
      'name': results.title
    }
  ])
   setTimeout(() => {
     setFetching(false)
   }, 1000)
})

 }

  // const fetch_detail_data = (impact_slug) => {
    
  //   setFetching(true);
  //   setData(sample_detail_response);
  //   setBreadcrumb([
  //     {
  //       'link': '/',
  //       'name': 'Home'
  //     },
  //     {
  //       'link': '/customers/',
  //       'name': 'Our Customers'
  //     },
  //     {
  //       'link': `/customers/${customer_slug}/`,
  //       'name': sample_detail_response.title
  //     }
  //   ])
  //   setTimeout(() => {
  //     setFetching(false)
  //   }, 1000);
  // }

  useEffect(() => {
    fetch_detail_data(customer_slug)
  }, [])

  return (
    <main className={'has_footer_artwork'}>
      <BreadCrumb color="#7A54F2"
                  icon_url={customers}
                  title="Our Customers"
                  breadcrumb_data={breadcrumb_data}
                  Artwork={BreadcrumbArtwork}/>
      <section className={'customers artwork'}>
        <Container>
          <div id={'customer-detail-container'}>
            {fetching ? (
              <div className={'d-flex justify-content-center align-items-center'} style={{height: '30vh'}}>
                <Spinner animation="border"/>
              </div>
            ) : (
              <>
                <div className={'customer_info'}>
                  <Row>
                    <Col xs={5} sm={2}>
                      <div className={'image-wrap'}>
                        <Image src={details.customer}/>
                      </div>
                    </Col>
                    <Col xs={7} sm={3} className={'text-right links'}>
                      {details.external_links.map((k, v) => (
                        <div key={v.toString()}>
                          <Link to="#" onClick={() => window.open(k.url, "_blank")} >{k.text}&nbsp;<DoubleArrowRight/></Link><br/>
                        </div>
                      ))}
                    </Col>
                  </Row>
                </div>
                <div className={'wave'}/>
                <div className={'tabs'}>
                  <div className={'tab-content w-100'}>
                    <Link to="#" className={active_tab === 'know' ? 'active' : ''}
                          onClick={() => toggle_tab('know')}>
                      Did you know
                    </Link>
                    <Link to="#" className={active_tab === 'value' ? 'active' : ''}
                          onClick={() => toggle_tab('value')}>
                      Our Value Add
                    </Link>
                    <Link to="#" className={active_tab === 'team' ? 'active' : ''}
                          onClick={() => toggle_tab('team')}>
                      Meet the team
                    </Link>
                  </div>
                </div>
                {tab_loading ? <CustomSpinner height={60}/> : (
                  <div className={'tab-content-wrap'}>
                    {active_tab === 'know' ? (
                      <div className={'row_detail'}>
                        <div className={'impact_content row'}>
                          <Row className={'align-items-center'}>
                            <Col sm={6} xs={12}>
                              <video src={details.docs[0].video} controls/>
                              <h6>{details.docs[0].title}</h6>
                            </Col>
                            <Col sm={6} xs={12}>
                              <BulletList list={details.timeline}/>
                            </Col>
                          </Row>
                        </div>
                      </div>
                    ) : null}
                    {active_tab === 'value' ? (
                      <CustomerValues setValueModal={setValueModal} details={details}
                                      show_value_modal={show_value_modal}/>
                    ) : null}
                    {active_tab === 'team' ? (
                      <CustomerTeam details={details}/>
                    ) : null}
                  </div>
                )}
                <div className={'row_detail'}>
                  <div className={'wave'}/>
                  <div className={'row_videos'}>
                    <Row>
                      {details.docs.map((k, v) => (
                        <Col key={v.toString()} sm={4} className={'mb-3'}>
                          <div className={'video_wrap'}>
                            <video src={k.video} controls/>
                            {k.tag.length > 0 ? (
                              <div className={'tag'}>
                                <span>{k.tag}</span>
                              </div>
                            ) : null}
                          </div>
                          <h6>
                            {k.title}
                          </h6>
                        </Col>
                      ))}
                    </Row>
                  </div>
                </div>
              </>
            )}
          </div>
        </Container>
      </section>
    </main>
  )
}

