import React, {useEffect, useState} from 'react'
import {Col, Container, Row} from "react-bootstrap";
import CustomSpinner from "../../components/CustomSpinner";
import CustomerHistory from "../../components/CustomerHistory";
import FifthThirdBank from "../../assets/fifthbank.png"
import Emerson from "../../assets/emersion.png"
import MTBANK from "../../assets/M&Tbank.png"
import BreadCrumb from "../../components/BreadCrumb";
import customers from "../../assets/customers.png";
import service from "../service/service.js";
import {ReactComponent as BreadcrumbArtwork} from "../../assets/customer-artwork.svg";


function Customers() {
  const [fetching, setFetching] = useState(false)
  const [data, setData] = useState([])
  const named_color_codes = {
    violet: '#A074F1',
    light_blue: '#69b6d5',
    dark_green: '#4ED164',
    pink: '#F153A6',
    dark_blue: '#387BFF',
  }

  const breadcrumb_data = [
    {
      'link': '/slk-hub/',
      'name': 'Home'
    },
    {
      'link': '/slk-hub/customers/',
      'name': 'Our Customers'
    }
  ]

  // const sample_response = {
  //   results: [
  //     {
  //       year: '2010',
  //       name: 'Fifth Third Bank',
  //       image: FifthThirdBank,
  //       slug: 'fifth-third-bank',
  //       hover_text: 'In consectetuer turpis ut velit. Pellentesque dapibus hendrerit tortor. In consectetuer turpis ut velit.'
  //     },
  //     {
  //       year: '2010',
  //       name: 'Emerson',
  //       image: Emerson,
  //       slug: 'emerson',
  //       hover_text: 'In consectetuer turpis ut velit. Pellentesque dapibus hendrerit tortor. In consectetuer turpis ut velit.'

  //     },
  //     {
  //       year: '2010',
  //       name: 'M&T Bank',
  //       image: MTBANK,
  //       slug: 'b-t-bank',
  //       hover_text: 'In consectetuer turpis ut velit. Pellentesque dapibus hendrerit tortor. In consectetuer turpis ut velit.'
  //     },
  //     {
  //       year: '2010',
  //       name: 'Fifth Third Bank',
  //       image: FifthThirdBank,
  //       slug: 'fifth-third-bank',
  //       hover_text: 'In consectetuer turpis ut velit. Pellentesque dapibus hendrerit tortor. In consectetuer turpis ut velit.'
  //     },
  //     {
  //       year: '2010',
  //       name: 'Fifth Third Bank',
  //       image: FifthThirdBank,
  //       slug: 'fifth-third-bank',
  //       hover_text: 'In consectetuer turpis ut velit. Pellentesque dapibus hendrerit tortor. In consectetuer turpis ut velit.'
  //     },
  //     {
  //       year: '2010',
  //       name: 'Fifth Third Bank',
  //       image: FifthThirdBank,
  //       slug: 'fifth-third-bank',
  //       hover_text: 'In consectetuer turpis ut velit. Pellentesque dapibus hendrerit tortor. In consectetuer turpis ut velit.'
  //     },
  //     {
  //       year: '2010',
  //       name: 'Fifth Third Bank',
  //       image: FifthThirdBank,
  //       slug: 'fifth-third-bank',
  //       hover_text: 'In consectetuer turpis ut velit. Pellentesque dapibus hendrerit tortor. In consectetuer turpis ut velit.'
  //     },
  //     {
  //       year: '2010',
  //       name: 'Fifth Third Bank',
  //       image: FifthThirdBank,
  //       slug: 'fifth-third-bank',
  //       hover_text: 'In consectetuer turpis ut velit. Pellentesque dapibus hendrerit tortor. In consectetuer turpis ut velit.'
  //     },
  //     {
  //       year: '2010',
  //       name: 'Fifth Third Bank',
  //       image: FifthThirdBank,
  //       slug: 'fifth-third-bank',
  //       hover_text: 'In consectetuer turpis ut velit. Pellentesque dapibus hendrerit tortor. In consectetuer turpis ut velit.'
  //     }
  //   ]
  // }


  const fetch_learning_data = () => {
    var results=[];
    service.getcustdetails()
    .then(res => {
       results=res.data;
        console.log(results);    
   setFetching(true)
   setData(results)
   setTimeout(() => {
     setFetching(false)
   }, 1000)
})

 }

  // const fetch_learning_data = () => {
  //   setFetching(true)
  //   setData(sample_response.results)
  //   setTimeout(() => {
  //     setFetching(false)
  //   }, 1000)
  // }

  useEffect(() => {
    fetch_learning_data()
  }, [])


  return (
    <main className={'has_footer_artwork'}>
      <BreadCrumb color="#7A54F2"
                  icon_url={customers}
                  title="Our Customers"
                  breadcrumb_data={breadcrumb_data}
                  Artwork={BreadcrumbArtwork}/>
      <section className={'customers'}>
        <Container>
         <Row className={'mt-5'}>          </Row>
          <Row className={'mt-5'}>
            <Col xs={12}>
              {fetching ? <CustomSpinner/> : (
                <>
                  {data.map((k, v) => {
                    let i = v >= 5 ? (v % 5) : v;
                    let color_key = Object.keys(named_color_codes)[i]
                    return <CustomerHistory key={v.toString()} even={v % 2 === 0}
                                            last={data.length === v + 1}
                                            color={named_color_codes[color_key]}
                                            color_name={color_key}
                                            slug={k.slug}
                                            image={k.image}
                                            hover_text={k.hover_text}
                                            year={k.year}/>
                  })}
                </>
              )}
            </Col>
          </Row>
        </Container>
      </section>
    </main>
  )
}

export default Customers
