import React, {useEffect, useState} from 'react'
import impact from '../../assets/impact.png';
import BreadCrumb from "../../components/BreadCrumb";
import {ReactComponent as BreadcrumbArtwork} from "../../assets/impact-artwork.svg"
import {
  Accordion,
  Button,
  Col,
  Container,
  Dropdown,
  DropdownButton,
  Image,
  Row,
  useAccordionToggle
} from "react-bootstrap";
import {Link} from "react-router-dom";
import CompanyLogo from "../../assets/emersion.png"
import {AiFillPlayCircle} from "react-icons/ai"
import ImpactDetail from "./ImpactDetail";
import CustomSpinner from "../../components/CustomSpinner";
import {ReactComponent as PlusCircle} from "../../assets/plus_circle.svg";
import service from "../service/service.js";

function Impact() {
  const [active_tab, setActiveTab] = useState('first_tab')
  const [first_table_data, setFirstData] = useState([])
  const [first_table_page, setFirstPage] = useState(1)
  const [first_table_filter_by, setFirstFilter] = useState('')
  const [second_table_data, setSecondData] = useState([])
  const [second_table_page, setSecondPage] = useState(1)
  const [fetching, setFetching] = useState(true)
  const [second_table_filter_by, setSecondFilter] = useState('')
  const [show_impact_slug, setImpactSlug] = useState('')

  const sample_response_page_1 = {
    page: 1,
    results: [
      {
        customer: "../.././Images/Emerson.jpg",
        solution: "Symphony",
        year: "2001",
        slk_champion: "Nagesh KP",
        slug: 'emersion_1',
        detail:
          {
             title:"Case Study: Symphony",
             type:"Transition/Stabilize/Reengineer",
             summary:"",
             keywords:[
                "Competitive Challenge","Business Critical","Transition from Bad Shape","Prove SLK Ability","Stabilize","Reengineer"
             ]
          }
       
      },
      {
        customer: CompanyLogo,
        solution: "Product Configuration",
        year: "2001",
        slk_champion: "Nagesh KP",
        slug: 'emersion_2',
        detail: {
          title: "Case Study: Inflation Model",
          type: "Type: New Solution/Application Key Words:",
          summary: "",
          keywords: ["Competitive Challenge","Business Critical","Transition from Bad Shape","Prove SLK Ability","Stabilize","Reengineer"]
        }
      },
      {
        customer: CompanyLogo,
        solution: "Inflation Model",
        year: "2001",
        slk_champion: "Nagesh KP",
        slug: 'emersion_3',
        detail: {
          title: "Case Study: Inflation Model",
          type: "Type: New Solution/Application Key Words:",
          summary: "",
          keywords: ["Procurement", "Forecast", "Data Analysis", "Reports", "Under Estimation"]
        }
      }
    ]
  }

  const fetch_first_table_data = (page = 1, filter_by = '') => {
    var results1=[];
    service.getImapcts("Simple")
    .then(res => {
       results1=res.data;
        console.log(results1);    
   setFetching(true)
   setFirstData(results1)
   setImpactSlug('')
   setTimeout(() => {
     setFetching(false)
   }, 1000)
})
}

const fetch_second_table_data = (page = 1, filter_by = '') => {
  var results=[];
  service.getImapcts("Complex")
  .then(res => {
     results=res.data;
      console.log(results);    
 setFetching(true)
 setSecondData(results)
 setImpactSlug('')
 setTimeout(() => {
   setFetching(false)
 }, 1000)
})

 }
  // const fetch_first_table_data = (page = 1, filter_by = '') => {
  //   setFetching(true);
  //   setFirstData(sample_response_page_1.results);
  //   setImpactSlug('')
  //   setTimeout(() => {
  //     setFetching(false)
  //   }, 1000);
  // }

  // const fetch_second_table_data = (page = 1, filter_by = '') => {
  //   setFetching(true);
  //   setSecondData(sample_response_page_1.results);
  //   setImpactSlug('')
  //   setTimeout(() => {
  //     setFetching(false)
  //   }, 1000);
  // }

  useEffect(() => {
    fetch_first_table_data(first_table_page, first_table_filter_by)
  }, [first_table_page, first_table_filter_by, active_tab])

  useEffect(() => {
    fetch_second_table_data(second_table_page, second_table_filter_by)
  }, [second_table_page, second_table_filter_by, active_tab])

  const [breadcrumb_data, setBreadcrumbData] = useState([
    {
      'link': '/',
      'name': 'Home'
    },
    {
      'link': '/impact/',
      'name': 'Our Impact'
    }
  ])


  const show_impact_details = (impact_slug,impact_id,customerid) => {
    // alert(impact_slug)
    // alert(impact_id)
    // alert(customerid)
    localStorage.setItem('impact_id', impact_id);
    localStorage.setItem('customerid', customerid);

    setImpactSlug(impact_slug)
  }

  const CustomToggle = ({eventKey, title}) => {
    const decoratedOnClick = useAccordionToggle(eventKey, () => {
      if (show_impact_slug.length > 0) {
        setImpactSlug('')
      }
    });

    return (
      <button onClick={decoratedOnClick} className="toggle_accordion">
        <h6>{title}</h6> <PlusCircle/>
      </button>
    );
  }

  const RenderFirstTableRow = ({item}) => (
    <Row className={`list_item ${item.slug}`}>
      <Col sm={12} md={2}>
        <div>
         <h6>Customer</h6>
          <Image src={item.customer}/>
        </div>
      </Col>
      <Col sm={12} md={2}>
        <h6>{item.solution}</h6>
      </Col>
      <Col sm={12} md={2}>
        <h6>{item.year}</h6>
      </Col>
      <Col sm={12} md={2}>
        <h6>{item.slk_champion}</h6>
      </Col>
      <Col sm={12} md={4} className={'has_accordion'}>
        <Accordion>
          <CustomToggle eventKey="0" title={item.detail.title}/>
          <Accordion.Collapse eventKey="0">
            <div className={'d-flex pt-3 align-items-baseline justify-content-between'}>
              <div>
                <p className={'strong'}>
                  {item.detail.type}
                </p>
                {item.detail.keywords.map((m, n) => <p key={n.toString()}>{m}</p>)}
              </div>
              <Button variant={'link'} onClick={() => show_impact_details(item.slug,item.Impact_id,item.customerid)} className={'play_link'}>
                <AiFillPlayCircle/>
              </Button>
            </div>
          </Accordion.Collapse>
        </Accordion>
      </Col>
    </Row>
  )

  const RenderSecondTableRow = ({item}) => (
    <Row className={`list_item ${item.slug}`}>
      <Col sm={12} md={2}>
        <div>
          <Image src={item.customer}/>
        </div>
      </Col>
      <Col sm={12} md={2}>
        <h6>{item.solution}</h6>
      </Col>
      <Col sm={12} md={2}>
        <h6>{item.year}</h6>
      </Col>
      <Col sm={12} md={2}>
        <h6>{item.slk_champion}</h6>
      </Col>
      <Col sm={12} md={4} className={'has_accordion'}>
        <Accordion>
          <CustomToggle eventKey="0" title={item.detail.title}/>
          <Accordion.Collapse eventKey="0">
            <div className={'d-flex pt-3 align-items-baseline justify-content-between'}>
              <div>
                <p className={'strong'}>
                  {item.detail.type}
                </p>
                {item.detail.keywords.map((m, n) => <p key={n.toString()}>{m}</p>)}
              </div>
              <Button variant={'link'} onClick={() => show_impact_details(item.slug,item.Impact_id,item.customerid)} className={'play_link'}>
                <AiFillPlayCircle/>
              </Button>
            </div>
          </Accordion.Collapse>
        </Accordion>
      </Col>
    </Row>
  )

  return (
    <main className={'has_footer_artwork'}>
      <BreadCrumb color="#A18CF6"
                  icon_url={impact}
                  title="Our Impact"
                  breadcrumb_data={breadcrumb_data}
                  Artwork={BreadcrumbArtwork}/>
      <section className={'impact artwork'}>
        <Container>
          <div className={'tabs'}>
            <div className={'tab-content'}>
              <Link to="#" className={active_tab === 'first_tab' ? 'active' : ''}
                    onClick={() => setActiveTab('first_tab')}>
                Building Impactful Solutions
              </Link>
              <Link to="#" className={active_tab === 'second_tab' ? 'active' : ''}
                    onClick={() => setActiveTab('second_tab')}>
                Transforming Complex Applications
              </Link>
            </div>
          </div>
          {show_impact_slug.length > 0 ?
            <ImpactDetail impact_slug={show_impact_slug} setImpactSlug={setImpactSlug}
                          setBreadcrumb={setBreadcrumbData}/> : (
              <>
                {fetching ? (
                  <CustomSpinner/>
                ) : (
                  <>
                    {active_tab === 'first_tab' ? (
                      <>
                        <div className={'custom-list'}>
                          <Row className={'list_head'}>
                            <Col sm={12} md={2}>
                              <h6>Customer</h6>
                            </Col>
                            <Col sm={12} md={2}>
                              <h6>Solution</h6>
                            </Col>
                            <Col sm={12} md={2}>
                              <h6>Year</h6>
                            </Col>
                            <Col sm={12} md={2}>
                              <h6>SLK Champion</h6>
                            </Col>
                            <Col sm={12} md={4}>
                              <h6>Detail</h6>
                              <DropdownButton
                                size="sm"
                                menuAlign="right"
                                title="FILTER SORT BY"
                                id="sort_by"
                              >
                                <Dropdown.Item eventKey="3"
                                               onClick={() => setFirstFilter('customer')}>Customer</Dropdown.Item>
                                <Dropdown.Item eventKey="1"
                                               onClick={() => setFirstFilter('year')}>Year</Dropdown.Item>
                                <Dropdown.Item eventKey="2"
                                               onClick={() => setFirstFilter('slk_champion')}>
                                  SLK Champion
                                </Dropdown.Item>
                              </DropdownButton>
                            </Col>
                          </Row>
                          {first_table_data.map((k, v) => <RenderFirstTableRow key={v.toString()} item={k}/>)}
                        </div>
                        <div className={'pages'}>
                          <Link to='#' onClick={() => setFirstPage(1)}
                                className={first_table_page === 1 ? 'active' : ''}>1</Link>
                          {/* <Link to='#' onClick={() => setFirstPage(2)}
                                className={first_table_page === 2 ? 'active' : ''}>2</Link>
                          <Link to='#' onClick={() => setFirstPage(3)}
                                className={first_table_page === 3 ? 'active' : ''}>3</Link> */}
                        </div>
                      </>
                    ) : (
                      <>
                        <div className={'custom-list'}>
                          <Row className={'list_head'}>
                            <Col sm={12} md={2}>
                              <h6>Customer</h6>
                            </Col>
                            <Col sm={12} md={2}>
                              <h6>Solution</h6>
                            </Col>
                            <Col sm={12} md={2}>
                              <h6>Year</h6>
                            </Col>
                            <Col sm={12} md={2}>
                              <h6>SLK Champion</h6>
                            </Col>
                            <Col sm={12} md={4}>
                              <h6>Detail</h6>
                              <DropdownButton
                                size="sm"
                                menuAlign="right"
                                title="FILTER SORT BY"
                                id="sort_by"
                              >
                                <Dropdown.Item eventKey="3"
                                               onClick={() => setSecondFilter('customer')}>Customer</Dropdown.Item>
                                <Dropdown.Item eventKey="1"
                                               onClick={() => setSecondFilter('year')}>Year</Dropdown.Item>
                                <Dropdown.Item eventKey="2"
                                               onClick={() => setSecondFilter('slk_champion')}>
                                  SLK Champion
                                </Dropdown.Item>
                              </DropdownButton>
                            </Col>
                          </Row>
                          {second_table_data.map((k, v) => <RenderSecondTableRow key={v.toString()} item={k}/>)}
                        </div>
                        <div className={'pages'}>
                          <Link to='#' onClick={() => setSecondPage(1)}
                                className={second_table_page === 1 ? 'active' : ''}>1</Link>
                          {/* <Link to='#' onClick={() => setSecondPage(2)}
                                className={second_table_page === 2 ? 'active' : ''}>2</Link>
                          <Link to='#' onClick={() => setSecondPage(3)}
                                className={second_table_page === 3 ? 'active' : ''}>3</Link> */}
                        </div>
                      </>
                    )}
                  </>
                )}
              </>
            )}
        </Container>
      </section>
    </main>
  )
}

export default Impact
