import React, {useEffect, useState} from 'react'
import CustomSpinner from "../../components/CustomSpinner";
import OfficeHistory from "../../components/OfficeHistory";
import service from "../service/service.js";

function EvolutionOffice() {
  const [fetching, setFetching] = useState(false)
  const [data, setData] = useState([])
  const color_codes = ['#F20F87', '#69b6d5', '#F9D05E', '#FF4DD5', '#4E99DB', '#4E99DB', '#EF4343', '#A074F1']

  /*const sample_response = {
    results: [
      {
        title: 'The Beginning',
        description: 'An acquisition by SLK \n of a niche Digital \n Creative Experience Company \n Based on CA, USA',
        year: '2010',
        video: SampleVideo2
      },
      {
        title: 'Vyalikaval',
        description: 'An acquisition by SLK \n of a niche Digital \n Creative Experience Company \n Based on CA, USA',
        year: '2010',
        video: SampleVideo2
      },
      {
        title: 'Niran Arcade',
        description: 'An acquisition by SLK \n of a niche Digital \n Creative Experience Company \n Based on CA, USA',
        year: '2010',
        video: SampleVideo2
      },
      {
        title: 'Vacuum House',
        description: 'An acquisition by SLK \n of a niche Digital \n Creative Experience Company \n Based on CA, USA',
        year: '2010',
        video: SampleVideo2
      },
      {
        title: 'SLK 1, Yelahanka',
        description: 'An acquisition by SLK \n of a niche Digital \n Creative Experience Company \n Based on CA, USA',
        year: '2010',
        video: SampleVideo2
      },
      {
        title: 'MFAR',
        description: 'An acquisition by SLK \n of a niche Digital \n Creative Experience Company \n Based on CA, USA',
        year: '2010',
        video: SampleVideo2
      },
      {
        title: 'SLK Green Park Campus',
        description: 'An acquisition by SLK \n of a niche Digital \n Creative Experience Company \n Based on CA, USA',
        year: '2010',
        video: SampleVideo2
      },
    ]
  }*/

const fetch_learning_data = () => {
     var results=[];
     service.getevolofficedetails()
     .then(res => {
        results=res.data;
         console.log("office",results);    
    setFetching(true)
    setData(results)
    setTimeout(() => {
      setFetching(false)
    }, 1000)
 })

  }
  useEffect(() => {
    fetch_learning_data()
  }, [])


  return (
    <>
      {fetching ? <CustomSpinner/> : (
        <>
          {data.map((k, v) => {
            let color = color_codes[v >= 8 ? (v % 8) : v];
            return <OfficeHistory key={v.toString()}
                                  last={data.length === v + 1}
                                  first={v === 0}
                                  color={color}
                                  year={k.Year} title={k.Name}
                                  description={k.Description}
                                  video_link={k.Doc_Path}/>
          })}
        </>
      )}
    </>
  )
}

export default EvolutionOffice
