import React, {useEffect, useState} from 'react'
import {Button, Col, Image, Row, Spinner} from "react-bootstrap";
import CompanyLogo from "../../assets/emersion.png"
import SampleVideo from "../../assets/sample2.mp4"
import BulletList from "../../components/BulletList";
import {AiFillMinusCircle} from "react-icons/ai";
import service from "../service/service.js";

function EvolutionKeyProgramDetail({program_slug, setProgramSlug}) {
  const [details, setData] = useState({})
  const [fetching, setFetching] = useState(true)

  const sample_detail_response = {
    customer: CompanyLogo,
    solution: "Inflation Model",
    year: "2001",
    slk_champion: "Nagesh KP",
    slug: 'emersion_1',
    title: 'Emersion',
    detail: {
      title: "Case Study: Inflation Model",
      type: "Type: New Solution/Application Key Words:",
      summary: "",
      keywords: ["Procurement", "Forecast", "Data Analysis", "Reports", "Under Estimation"]
    },
    timeline: [
      "Customer since - 1998", "Industry - Automation-Solutions",
      "Projects 1 - Automation Engineering",
      "Projects 2 Industrial Wireless Technology",
      "Award - Operational Excellence"
    ],
    docs: [
      {
        'video': SampleVideo,
        'title': 'Evolving from Automation to Hyper Automation',
        'tag': 'Document'
      },
      {
        'video': SampleVideo,
        'title': 'The Future of Blockchain',
        'tag': ''
      },
      {
        'video': SampleVideo,
        'title': 'How to transition from Monolithic to Microservices?',
        'tag': 'Document'
      }
    ]
  }

  // const fetch_detail_data = (impact_slug) => {
  //   setFetching(true);
  //   setData(sample_detail_response);
  //   setTimeout(() => {
  //     setFetching(false)
  //   }, 1000);
  // }
  const fetch_detail_data = (program_slug) => {
    var results;
    var customerid=parseInt(localStorage.getItem('customerid'));
    var impact_id=parseInt(localStorage.getItem('impact_id'));
    // alert(customerid);
    // alert(impact_id);
    service.getImapctdetailsbyid(customerid,impact_id)
    .then(res => {
       results=res.data;
        console.log(results);    
   setFetching(true)
   setData(results)
   setTimeout(() => {
     setFetching(false)
   }, 1000)
})
}

  useEffect(() => {
    fetch_detail_data(program_slug)
  }, [])

  return (
    <div id={'program-detail-container'}>
      {fetching ? (
        <div className={'d-flex justify-content-center align-items-center'} style={{height: '30vh'}}>
          <Spinner animation="border"/>
        </div>
      ) : (
        <div className={'row_detail'}>
          <div className={'custom-list'}>
            <Row className={'list_item'}>
              <Col sm={12} md={2}>
                <div>
                  <Image src={details.customer}/>
                </div>
              </Col>
              <Col sm={12} md={2}>
                <h6>{details.solution}</h6>
              </Col>
              <Col sm={12} md={2}>
                <h6>{details.year}</h6>
              </Col>
              <Col sm={12} md={2}>
                <h6>{details.slk_champion}</h6>
              </Col>
              <Col sm={12} md={4} className={'has_accordion'}>
                <div className={'d-flex pt-3 align-items-baseline justify-content-between'}>
                  <div>
                    <h6 className={'mb-3'}>{details.detail.title}</h6>
                    <p className={'strong'}>
                      {details.detail.type}
                    </p>
                    {details.detail.keywords.map((m, n) => <p>{m}</p>)}
                  </div>
                  <Button variant={'link'} onClick={() => setProgramSlug('')} className={'pause_link'}>
                    <AiFillMinusCircle/>
                  </Button>
                </div>
              </Col>
            </Row>
          </div>
          <div className={'impact_content row'}>
            <Row>
              <Col sm={6} xs={12}>
                <video src={details.docs[0].video} controls/>
                <h6>{details.docs[0].title}</h6>
              </Col>
              <Col sm={6} xs={12}>
                <BulletList list={details.timeline}/>
              </Col>
            </Row>
          </div>
          <div className={'row_videos'}>
            <Row>
              {details.docs.map((k, v) => (
                <Col sm={4} className={'mb-3'}>
                  <div className={'video_wrap'}>
                    <video src={k.video} controls/>
                    {k.tag.length > 0 ? (
                      <div className={'tag'}>
                        <span>{k.tag}</span>
                      </div>
                    ) : null}
                  </div>
                  <h6>
                    {k.title}
                  </h6>
                </Col>
              ))}
            </Row>
          </div>
        </div>
      )}
    </div>
  )
}

export default EvolutionKeyProgramDetail
