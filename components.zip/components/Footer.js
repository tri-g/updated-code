import React from 'react'
import {Container} from "react-bootstrap";


function Footer() {
  return (
    <footer>
      <div id="footer-wrap">
        <Container>
          <p>
            Copyright <i className="fa fa-copyright"></i> 2020 SLK Software Services Pvt Ltd. All rights reserved.
          </p>
        </Container>
      </div>
    </footer>
  );
}

export default Footer;
