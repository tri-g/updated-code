import {Col, Image, Row} from "react-bootstrap";
import {Link} from "react-router-dom";
import React from "react";
import Emerson from "../assets/emersion.png"

export default function CustomerHistory({color, year, even, last, slug, image, color_name, hover_text}) {
  return (
    <>
    
      <Row className={'customer-history'}>
        <Col className={'left_col'}>
          {!even ? (
            <>
              <Link data-hover={hover_text} to={`/customers/${slug}/`} className={`${color_name} left`}>
                <Image src={image}/>
              </Link>
              <h6 className={'title'}>{year}</h6>
            </>
          ) : null}
        </Col>
        <Col xs={1}>
          <div className={'dots'}>
            <div>
              <div className={'circle'} style={{borderColor: color}}/>
            </div>
            {!last ? <div className={'line'}/> : null}
          </div>
        </Col>
        <Col className={'right_col'}>
          {even ? (
            <>
              <h6 className={'title'}>{year}</h6>
              <Link data-hover={hover_text} to={`/customers/${slug}/`} className={`${color_name} right`}>
                 <Image src={image}/>
              </Link>
            </>
          ) : null}
        </Col>
      </Row>
    </>
  )
}
