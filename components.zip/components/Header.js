import React from 'react'
import {Accordion, Button, Container, Form} from "react-bootstrap";
import {Link, useRouteMatch, withRouter} from "react-router-dom";
import {FaFacebookF, FaLinkedinIn, FaTwitter} from "react-icons/fa"
import {ReactComponent as Logo} from '../assets/logo.svg';

function Header() {

  const openNav = () => {
    document.getElementById("sidenav-wrap").className = "show";
  }

  const closeNav = () => {
    document.getElementById("sidenav-wrap").className = "";
  }

  let {url} = useRouteMatch();

  return (
    <header className="shadow">
      <Container>
        <div id={'header-main'}>
          <div className="logo">
            <Link to={url}>
              <Logo/>
            </Link>
          </div>
 
    
          <div className="right-menu">
            
            <div className={'secondary-menu'}>
            
            <Form>
             <div className="input-container">
              <i className="fa fa-search icon"></i>
              <Form.Control type="text" placeholder="Search Videos, Documents" className="input-field" />
             </div> </Form>
              <Button onClick={() => openNav()} className={'menu-icon'}/>
            </div>
          </div>
        </div>
        <Accordion.Collapse eventKey="0">
          <Container>
            <div>Hello! I'm the body</div>
          </Container>
        </Accordion.Collapse>
      </Container>
      <div id="sidenav-wrap">
        <div id="sidenav" className="sidenav">
          <Link to="#" className="closebtn" onClick={() => closeNav()}>&times;</Link>
          <Container>
            <ul>
              <li><Link onClick={() => closeNav()} to="/ethos/">Our Ethos</Link></li>
              <li><Link onClick={() => closeNav()} to="/evolution/">Our Evolution</Link></li>
              <li><Link onClick={() => closeNav()} to="/customers/">Our Customers</Link></li>
              <li><Link onClick={() => closeNav()} to="/people/">Our People</Link></li>
              <li><Link onClick={() => closeNav()} to="/impact/">Our Impact</Link></li>
              <li><Link onClick={() => closeNav()} to="/learnings/">Our Learnings</Link></li>
            </ul>
            <div className="footer">
              <Link to="#"><FaFacebookF/></Link>
              <Link to="#"><FaTwitter/></Link>
              <Link to="#"><FaLinkedinIn/></Link>
            </div>
          </Container>
        </div>
      </div>
    </header>
  );
}

export default withRouter(Header);
