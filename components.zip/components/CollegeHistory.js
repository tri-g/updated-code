import {Col, Image, Modal, Row} from "react-bootstrap";
import Carousel from "react-multi-carousel";
import {ReactComponent as REDDOT} from "../assets/red_dot.svg";
import {ReactComponent as REDDOTFULL} from "../assets/red_dot_full.svg";
import {ReactComponent as BLACKDOT} from "../assets/black_dot.svg";
import {ReactComponent as PLAY} from "../assets/play.svg";
import React, {useState} from "react";
import RightIcon from "../assets/history_right_icon.png";
import LeftIcon from "../assets/history_left_icon.png";
import {Link} from "react-router-dom";

export default function CollegeHistory({last, image_url, name, video_link, video_description, records}) {
  const responsive = {
    superLargeDesktop: {
      breakpoint: {max: 4000, min: 3000},
      items: 6
    },
    desktop: {
      breakpoint: {max: 3000, min: 1024},
      items: 5
    },
    tablet: {
      breakpoint: {max: 1024, min: 464},
      items: 3
    },
    mobile: {
      breakpoint: {max: 464, min: 0},
      items: 2
    }
  };

  const CustomRight = ({onClick}) => (
    <button className="arrow right" onClick={onClick}>
      <Image src={RightIcon}/>
    </button>
  );

  const CustomLeft = ({onClick}) => (
    <button className="arrow left" onClick={onClick}>
      <Image src={LeftIcon}/>
    </button>
  );

  const [show_video_modal, setVideoModal] = useState(false)

  return (
    <>
      <Row>
        <Col xs={12} md={3}>
          <div className={'profile_pic'}>
            <Link to="#" onClick={() => setVideoModal(true)}>
              <Image src={image_url}/>
              <div id="play_button">
                <PLAY/>
              </div>
            </Link>
          </div>
          <div className={'name'}>
            <span>{name}</span>
          </div>
        </Col>
        <Col xs={12} md={9}>
          <Carousel responsive={responsive} customRightArrow={<CustomRight/>} customLeftArrow={<CustomLeft/>}>
            {records.map((k, v) => (
              <div key={v.toString()} className={'timeline-wrapper'}>
                <div className={'timeline'}>
                  <div className={'title'}>
                    {k.highlight ? <span style={{color: '#F20F87', fontWeight: 'bold'}}>{k.title}</span> :
                      <span>{k.title}</span>}
                  </div>
                  <div className={'dots'}>
                    <div className={'line'}/>
                    <div className={'circle'}>
                      {k.star ? <REDDOTFULL className={'full'}/> : (k.highlight ? <REDDOT/> : <BLACKDOT/>)}
                    </div>
                    <div className={'line'}/>
                  </div>
                  {k.highlight ? <div className={'year'} style={{color: '#F20F87', fontWeight: 'bold'}}>{k.year}</div> :
                    <div className={'year'}>{k.year}</div>}
                </div>
              </div>
            ))}
          </Carousel>
        </Col>
      </Row>
      {!last ? <div className={'wave my-4'}/> : null}
      <Modal
        size="md"
        className={'video_modal'}
        show={show_video_modal}
        onHide={() => console.log('closed')}
        backdrop="static">
        <div className={'close_button'} onClick={() => setVideoModal(false)}/>
        <div className={'video_wrap'}>
          <video id={'video_block'} src={video_link} controls
                 autoPlay/>
        </div>
        <div className={'video_links'}>
          <p className={'m-0 px-3 text-white'}>{video_description}</p>
        </div>
      </Modal>
    </>
  )
}
